#define PROJECT_VERSION                 "8.5.9"
#define PROJECT_VERSION_MAJOR           8
#define PROJECT_VERSION_MINOR           5
#define PROJECT_VERSION_MICRO           9
#define PROJECT_VERSION_REVISION        2153316352UL
#define PROJECT_VERSION_COMMIFIED       "8,5,9"
