#define PROJECT_VERSION                 "8.7.20"
#define PROJECT_VERSION_MAJOR           8
#define PROJECT_VERSION_MINOR           7
#define PROJECT_VERSION_MICRO           20
#define PROJECT_VERSION_REVISION        0UL
#define PROJECT_VERSION_COMMIFIED       "8,7,20"
