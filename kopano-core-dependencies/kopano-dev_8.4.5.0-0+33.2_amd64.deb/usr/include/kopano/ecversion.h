#define PROJECT_VERSION                 "8.4.5.0"
#define PROJECT_VERSION_MAJOR           8
#define PROJECT_VERSION_MINOR           4
#define PROJECT_VERSION_MICRO           5
#define PROJECT_VERSION_REVISION        2152005632UL
#define PROJECT_VERSION_COMMIFIED       "8,4,5"
